function EEChanges(ee) {
    switch (ee.Name) {
        case "Pure":
            ee.Name = "Depraved"
            break;
        default:
            break;
    }
    switch (ee.Race) {
        default:
            break;
    }
}
/* Not in use for the moment but I made it so that if I add more scenarios like pure maiden, it's easy 
    to expand on*/