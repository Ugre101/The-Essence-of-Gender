// Ideas for blessing to add later to unlock
var Blessings = {
    Incubator: 0, /* add behind baby age at preg engine to change time before birth have like a quest to get it*/
    Breeder: 0, // same but for dorm servants
    TwinsChance: 0 // remake impregnation so you can have twins or more
}

// Ideas for curses player can get stuck with until finding way to get rid of
var Curses = {
    Hunger: 0, // increase fatburn to force player into overeating to stop starving
    Sub: 0, // Gives player a random chance to just lose a battle
    Race: "Race" // Makes it so player contantly changes to a race
}